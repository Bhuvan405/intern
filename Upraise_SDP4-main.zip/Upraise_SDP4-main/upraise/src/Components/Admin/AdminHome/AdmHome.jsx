import React from 'react'
import './admhome.css'
import Admheader from '../AdmHeader/Admheader'
export default function AdmHome() {
  return (
    <div>
        <Admheader />
        
    </div>
  )
}
